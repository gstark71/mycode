#!/usr/bin/python3

"""Stark Labs | Gstark
   Packaging Python Project"""

name = "example_pkg"
